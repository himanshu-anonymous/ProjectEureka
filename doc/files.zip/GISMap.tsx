'use client';

import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { useDashboardStore } from '@/stores/dashboardStore';
import {
  DISTRICT_BY_ID,
  DISTRICT_GEOMETRY,
  DIVISIONS,
  DIVISION_BORDERS_PATH,
  DIVISION_ORDER,
  MAP_HEIGHT,
  MAP_WIDTH,
  STATE_OUTLINE_PATH,
  type DistrictGeometry,
  type DistrictId,
  type DivisionId,
} from '@/data/maharashtraGeo.generated';
import { DIO_BY_DISTRICT, type DioStatus } from '@/data/dioDirectory';

/* -------------------------------------------------------------------------- */
/* Types & constants                                                          */
/* -------------------------------------------------------------------------- */

type StatusKey = DioStatus | 'Not configured';
type ColorMode = 'division' | 'status';
/** Visible window into the map. Height is derived from width to keep the aspect ratio. */
interface ViewBox {
  x: number;
  y: number;
  w: number;
}

const COLORS = {
  selected: '#1B2A4A', // navy
  inspected: '#1E40AF', // Ashoka blue
  pin: '#D97706',
  divisionBorder: '#1B2A4A',
};

const DIVISION_FILL: Record<DivisionId, string> = {
  konkan: '#9ED7D2',
  nashik: '#F3D58E',
  pune: '#A9BFF0',
  'chhatrapati-sambhajinagar': '#E9AEBE',
  amravati: '#B5DDA4',
  nagpur: '#F5BD98',
};

// Same hues as the status badges in the info card, so map and badge always agree.
const STATUS_FILL: Record<StatusKey, string> = {
  Active: '#6EE7B7',
  Standby: '#FCD34D',
  'Field Operation': '#93C5FD',
  'Not configured': '#E2E8F0',
};

const STATUS_BADGE: Record<StatusKey, string> = {
  Active: 'bg-emerald-50 text-emerald-800 border-emerald-300',
  Standby: 'bg-amber-50 text-amber-800 border-amber-300',
  'Field Operation': 'bg-blue-50 text-blue-800 border-blue-300',
  'Not configured': 'bg-slate-50 text-slate-600 border-slate-300',
};

const STATUS_ORDER: StatusKey[] = ['Active', 'Standby', 'Field Operation', 'Not configured'];

const DEFAULT_DISTRICT_ID: DistrictId = 'pune';

/** IDs used by the previous 8-zone version of this map, so older callers keep working. */
const LEGACY_ID_ALIASES: Record<string, DistrictId> = {
  mumbai: 'mumbai-city',
  aurangabad: 'chhatrapati-sambhajinagar',
};

const statusOf = (id: DistrictId): StatusKey => DIO_BY_DISTRICT[id]?.status ?? 'Not configured';

function resolveDistrictId(id: string | null | undefined): DistrictId | null {
  if (!id) return null;
  if (Object.prototype.hasOwnProperty.call(DISTRICT_BY_ID, id)) return id as DistrictId;
  return LEGACY_ID_ALIASES[id] ?? null;
}

// Static, so computed once rather than on every render.
const DISTRICTS_BY_DIVISION = DIVISION_ORDER.map((div) => ({
  div,
  districts: DISTRICT_GEOMETRY.filter((d) => d.division === div),
}));

const STATUS_COUNTS = DISTRICT_GEOMETRY.reduce(
  (acc, d) => ({ ...acc, [statusOf(d.id)]: acc[statusOf(d.id)] + 1 }),
  { Active: 0, Standby: 0, 'Field Operation': 0, 'Not configured': 0 } as Record<StatusKey, number>
);

const LEGEND: Record<ColorMode, { key: string; label: string; color: string; count: number }[]> = {
  division: DISTRICTS_BY_DIVISION.map(({ div, districts }) => ({
    key: div,
    label: DIVISIONS[div].name,
    color: DIVISION_FILL[div],
    count: districts.length,
  })),
  status: STATUS_ORDER.map((s) => ({ key: s, label: s, color: STATUS_FILL[s], count: STATUS_COUNTS[s] })),
};

/* -------------------------------------------------------------------------- */
/* Pan / zoom maths (pure)                                                    */
/* -------------------------------------------------------------------------- */

const MIN_W = MAP_WIDTH / 16; // max zoom 16x: enough to separate Mumbai City from Mumbai Suburban
const FULL_VIEW: ViewBox = { x: 0, y: 0, w: MAP_WIDTH };
const viewH = (w: number) => (w * MAP_HEIGHT) / MAP_WIDTH;
const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

function clampView(v: ViewBox): ViewBox {
  const w = clamp(v.w, MIN_W, MAP_WIDTH);
  return { w, x: clamp(v.x, 0, MAP_WIDTH - w), y: clamp(v.y, 0, MAP_HEIGHT - viewH(w)) };
}

/** Zoom by `factor`, keeping the point at fractional position (fx, fy) of the viewport fixed. */
function zoomView(v: ViewBox, factor: number, fx = 0.5, fy = 0.5): ViewBox {
  const w = clamp(v.w / factor, MIN_W, MAP_WIDTH);
  const anchorX = v.x + fx * v.w;
  const anchorY = v.y + fy * viewH(v.w);
  return clampView({ w, x: anchorX - fx * w, y: anchorY - fy * viewH(w) });
}

function fitView(b: DistrictGeometry['bbox']): ViewBox {
  const aspect = MAP_WIDTH / MAP_HEIGHT;
  const w = clamp(Math.max(b.w * 1.6, b.h * 1.6 * aspect), MIN_W, MAP_WIDTH);
  return clampView({ w, x: b.x + b.w / 2 - w / 2, y: b.y + b.h / 2 - viewH(w) / 2 });
}

/* -------------------------------------------------------------------------- */
/* Sub-components                                                             */
/* -------------------------------------------------------------------------- */

interface ShapeProps {
  district: DistrictGeometry;
  fill: string;
  onInspect: (id: DistrictId) => void;
  onSelect: (id: DistrictId) => void;
}

// Memoised: hovering re-renders the parent, but only the shapes whose fill changed update.
const DistrictShape = memo(function DistrictShape({ district, fill, onInspect, onSelect }: ShapeProps) {
  return (
    <path
      d={district.path}
      fill={fill}
      stroke="#FFFFFF"
      strokeWidth={1}
      strokeLinejoin="round"
      vectorEffect="non-scaling-stroke"
      className="cursor-pointer transition-[fill] duration-150"
      onMouseEnter={() => onInspect(district.id)}
      onClick={() => onSelect(district.id)}
    />
  );
});

const mapButton =
  'h-7 min-w-7 px-2 rounded border border-slate-200 bg-white/95 text-xs font-bold text-gov-primary shadow-2xs ' +
  'hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed ' +
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gov-blue';

/* -------------------------------------------------------------------------- */
/* Component                                                                  */
/* -------------------------------------------------------------------------- */

const LABEL_PX = 9;
const LABEL_CHAR_PX = 5;

export const GISMap: React.FC = () => {
  const { selectedDistrictId, setSelectedDistrictId } = useDashboardStore();
  const selectedId = resolveDistrictId(selectedDistrictId);

  // "Inspected" is the last district hovered or clicked. It is deliberately sticky: the info card
  // must not change while the pointer travels from the map to the card's button.
  const [inspectedId, setInspectedId] = useState<DistrictId>(selectedId ?? DEFAULT_DISTRICT_ID);
  const [colorMode, setColorMode] = useState<ColorMode>('division');
  const [view, setView] = useState<ViewBox>(FULL_VIEW);
  const [pxWidth, setPxWidth] = useState(420); // rendered width of the SVG in CSS px
  const [isDragging, setIsDragging] = useState(false);

  const svgRef = useRef<SVGSVGElement>(null);
  const dragRef = useRef<{ x: number; y: number; origin: ViewBox; moved: boolean; pointerId: number } | null>(null);
  const suppressClickRef = useRef(false);

  // If another widget (e.g. the leaderboard) changes the selection, follow it.
  useEffect(() => {
    if (selectedId) setInspectedId(selectedId);
  }, [selectedId]);

  // Track rendered size so labels and the pin stay a constant size on screen at any zoom.
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width;
      if (w) setPxWidth(w);
    });
    ro.observe(svg);
    return () => ro.disconnect();
  }, []);

  // Ctrl/Cmd + wheel zooms. A plain wheel keeps scrolling the dashboard. Needs a native,
  // non-passive listener because React's onWheel can't call preventDefault.
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      const rect = svg.getBoundingClientRect();
      const fx = (e.clientX - rect.left) / rect.width;
      const fy = (e.clientY - rect.top) / rect.height;
      setView((v) => zoomView(v, Math.exp(-e.deltaY * 0.0025), fx, fy));
    };
    svg.addEventListener('wheel', onWheel, { passive: false });
    return () => svg.removeEventListener('wheel', onWheel);
  }, []);

  const inspectDistrict = useCallback((id: DistrictId) => setInspectedId(id), []);
  const selectDistrict = useCallback(
    (id: DistrictId) => {
      if (suppressClickRef.current) return; // the click that ends a drag is not a selection
      setInspectedId(id);
      setSelectedDistrictId(id);
    },
    [setSelectedDistrictId]
  );

  /* Drag to pan (only when zoomed in). Pointer capture starts after a 4px threshold so that a
     plain click on a district still reaches the district. */
  const onPointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if (e.button !== 0 || view.w >= MAP_WIDTH) return;
    dragRef.current = { x: e.clientX, y: e.clientY, origin: view, moved: false, pointerId: e.pointerId };
  };
  const onPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    const d = dragRef.current;
    if (!d || d.pointerId !== e.pointerId) return;
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    if (!d.moved) {
      if (Math.hypot(dx, dy) < 4) return;
      d.moved = true;
      e.currentTarget.setPointerCapture(e.pointerId);
      setIsDragging(true);
    }
    const unit = d.origin.w / pxWidth;
    setView(clampView({ ...d.origin, x: d.origin.x - dx * unit, y: d.origin.y - dy * unit }));
  };
  const endDrag = (e: React.PointerEvent<SVGSVGElement>) => {
    const d = dragRef.current;
    if (!d) return;
    if (d.moved) {
      suppressClickRef.current = true;
      setTimeout(() => (suppressClickRef.current = false), 0);
      if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
    }
    dragRef.current = null;
    setIsDragging(false);
  };

  /* Derived values */
  const inspected = DISTRICT_BY_ID[inspectedId];
  const inspectedDio = DIO_BY_DISTRICT[inspectedId];
  const inspectedStatus = statusOf(inspectedId);
  const isZoomed = view.w < MAP_WIDTH - 0.5;
  const unit = view.w / pxWidth; // map units per CSS pixel

  const fillFor = (d: DistrictGeometry): string => {
    if (d.id === selectedId) return COLORS.selected;
    if (d.id === inspectedId) return COLORS.inspected;
    return colorMode === 'division' ? DIVISION_FILL[d.division] : STATUS_FILL[statusOf(d.id)];
  };

  // Only label districts big enough on screen to hold their name; more appear as you zoom in.
  const labelled = DISTRICT_GEOMETRY.filter((d) => {
    if (d.id === inspectedId) return false; // the pin sits there
    const widthPx = d.bbox.w / unit;
    const heightPx = d.bbox.h / unit;
    return widthPx * 0.85 >= d.label.length * LABEL_CHAR_PX && heightPx >= LABEL_PX * 1.6;
  });

  return (
    <div className="bg-surface border border-slate-200 rounded-lg flex flex-col h-full shadow-xs overflow-hidden">
      {/* Header matching Wireframe 2 */}
      <div className="px-4 py-3 border-b border-slate-200 bg-surface flex items-center justify-between flex-wrap gap-2">
        <div>
          <h3 className="text-sm font-bold text-gov-primary tracking-tight">Maharashtra GIS Map</h3>
          <p className="text-[11px] text-slate-500 font-medium">
            Interactive map with real-time hover states for all {DISTRICT_GEOMETRY.length} District Information Offices
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="gis-district-select" className="sr-only">
            Select a district
          </label>
          <select
            id="gis-district-select"
            value={selectedId ?? ''}
            onChange={(e) => selectDistrict(e.target.value as DistrictId)}
            className="text-[11px] font-semibold text-gov-primary bg-white border border-slate-200 rounded px-2 py-0.5 max-w-44 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gov-blue"
          >
            {!selectedId && (
              <option value="" disabled>
                Select district…
              </option>
            )}
            {DISTRICTS_BY_DIVISION.map(({ div, districts }) => (
              <optgroup key={div} label={`${DIVISIONS[div].name} division`}>
                {districts.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
          <span className="text-[11px] font-bold text-gov-primary bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
            {DISTRICT_GEOMETRY.length} DIO Network
          </span>
        </div>
      </div>

      <div className="p-3.5 flex-1 flex flex-col md:flex-row gap-4 items-center justify-between">
        {/* Map column */}
        <div className="w-full md:w-3/5 flex flex-col gap-2">
          <div
            className="relative w-full bg-gradient-to-b from-slate-50 to-blue-50/30 rounded-lg border border-slate-200 overflow-hidden shadow-inner"
            style={{ aspectRatio: `${MAP_WIDTH} / ${MAP_HEIGHT}` }}
          >
            <svg
              ref={svgRef}
              viewBox={`${view.x} ${view.y} ${view.w} ${viewH(view.w)}`}
              role="img"
              aria-label={`Map of Maharashtra with all ${DISTRICT_GEOMETRY.length} districts. Use the district selector above for keyboard access.`}
              className={`absolute inset-0 w-full h-full ${isDragging ? 'cursor-grabbing' : isZoomed ? 'cursor-grab' : ''}`}
              style={{ touchAction: isZoomed ? 'none' : 'auto' }}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
            >
              {/* Districts */}
              {DISTRICT_GEOMETRY.map((d) => (
                <DistrictShape
                  key={d.id}
                  district={d}
                  fill={fillFor(d)}
                  onInspect={inspectDistrict}
                  onSelect={selectDistrict}
                />
              ))}

              {/* Division borders and state outline, drawn from the shared topology */}
              <g fill="none" stroke={COLORS.divisionBorder} strokeLinejoin="round" pointerEvents="none">
                <path d={DIVISION_BORDERS_PATH} strokeWidth={1.5} strokeOpacity={0.55} vectorEffect="non-scaling-stroke" />
                <path d={STATE_OUTLINE_PATH} strokeWidth={1.75} vectorEffect="non-scaling-stroke" />
              </g>

              {/* Crisp outlines on top so neighbours never cover the highlighted border */}
              {inspectedId !== selectedId && (
                <path
                  d={inspected.path}
                  fill="none"
                  stroke={COLORS.inspected}
                  strokeWidth={2}
                  strokeLinejoin="round"
                  vectorEffect="non-scaling-stroke"
                  pointerEvents="none"
                />
              )}
              {selectedId && (
                <path
                  d={DISTRICT_BY_ID[selectedId].path}
                  fill="none"
                  stroke={COLORS.selected}
                  strokeWidth={2}
                  strokeLinejoin="round"
                  vectorEffect="non-scaling-stroke"
                  pointerEvents="none"
                />
              )}

              {/* District names; font size is in map units, scaled so it is constant on screen */}
              <g
                className="select-none"
                pointerEvents="none"
                fontSize={LABEL_PX * unit}
                fontWeight={600}
                textAnchor="middle"
                dominantBaseline="central"
              >
                {labelled.map((d) => {
                  const isSelected = d.id === selectedId;
                  return (
                    <g key={d.id}>
                      {/* Halo and text are separate elements rather than using paint-order,
                          which print/PDF/screenshot renderers and older engines ignore. */}
                      <text
                        x={d.pin.x}
                        y={d.pin.y}
                        fill="none"
                        stroke={isSelected ? COLORS.selected : '#FFFFFF'}
                        strokeWidth={LABEL_PX * unit * 0.28}
                        strokeLinejoin="round"
                      >
                        {d.label}
                      </text>
                      <text x={d.pin.x} y={d.pin.y} fill={isSelected ? '#FFFFFF' : '#0F172A'}>
                        {d.label}
                      </text>
                    </g>
                  );
                })}
              </g>

              {/* Marker on the inspected district, placed at its deepest interior point */}
              <g transform={`translate(${inspected.pin.x} ${inspected.pin.y}) scale(${unit})`} pointerEvents="none">
                <circle
                  r={8}
                  fill={COLORS.pin}
                  opacity={0.3}
                  className="animate-ping motion-reduce:animate-none"
                  style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
                />
                <circle r={5} fill={COLORS.pin} stroke="#FFFFFF" strokeWidth={1.5} />
                <circle r={2} fill="#FFFFFF" />
              </g>
            </svg>

            {/* Zoom controls */}
            <div className="absolute bottom-2 right-2 flex items-center gap-1">
              <button
                type="button"
                className={mapButton}
                aria-label="Zoom out"
                disabled={!isZoomed}
                onClick={() => setView((v) => zoomView(v, 1 / 1.6))}
              >
                −
              </button>
              <button
                type="button"
                className={mapButton}
                aria-label="Zoom in"
                disabled={view.w <= MIN_W + 0.01}
                onClick={() => setView((v) => zoomView(v, 1.6))}
              >
                +
              </button>
              <button
                type="button"
                className={mapButton}
                aria-label={`Zoom to ${inspected.name}`}
                onClick={() => setView(fitView(inspected.bbox))}
              >
                Zoom to district
              </button>
              <button type="button" className={mapButton} disabled={!isZoomed} onClick={() => setView(FULL_VIEW)}>
                Reset
              </button>
            </div>
          </div>

          {/* Colour mode + legend */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
            <div
              role="group"
              aria-label="Colour the map by"
              className="inline-flex rounded border border-slate-200 overflow-hidden text-[11px] font-semibold"
            >
              {(['division', 'status'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  aria-pressed={colorMode === mode}
                  onClick={() => setColorMode(mode)}
                  className={`px-2.5 py-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-gov-blue ${
                    colorMode === mode ? 'bg-gov-primary text-white' : 'bg-white text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {mode === 'division' ? 'By division' : 'By DIO status'}
                </button>
              ))}
            </div>
            <ul className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-600">
              {LEGEND[colorMode].map((item) => (
                <li key={item.key} className="inline-flex items-center gap-1.5">
                  <span
                    className="h-2.5 w-2.5 rounded-sm border border-slate-300"
                    style={{ background: item.color }}
                    aria-hidden="true"
                  />
                  {item.label} <span className="text-slate-400">({item.count})</span>
                </li>
              ))}
            </ul>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Click a district to sync Leaderboard &amp; Score zones. Ctrl/⌘ + scroll or the buttons to zoom; drag to pan.
            Boundaries: Census 2011 with Palghar (2014), simplified for display.
          </p>
        </div>

        {/* Hover State Card — formatted strictly as in Wireframe 2 */}
        <div className="w-full md:w-2/5 border-2 border-gov-blue/30 p-3.5 rounded-lg bg-white shadow-xs space-y-2.5">
          <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-200">
            <div className="min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">District Hover State</span>
              <h4 className="text-sm font-bold text-gov-primary">District: [{inspected.name}]</h4>
              <p lang="mr" className="text-xs text-slate-500">
                {inspected.nameMr}
              </p>
            </div>
            <span
              className={`shrink-0 px-2 py-0.5 rounded-full text-[10px] font-bold border ${STATUS_BADGE[inspectedStatus]}`}
            >
              DIO Status: {inspectedStatus}
            </span>
          </div>

          <div className="space-y-1.5 text-xs text-slate-700">
            <div className="flex justify-between gap-2">
              <span className="text-slate-500">Liaison Officer:</span>
              {inspectedDio ? (
                <strong className="text-slate-900 text-right">{inspectedDio.officer}</strong>
              ) : (
                <span className="text-slate-400 italic">Not assigned</span>
              )}
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-slate-500">Administrative Division:</span>
              <strong className="text-slate-900 text-right">{DIVISIONS[inspected.division].name}</strong>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-slate-500">DIO Gateway:</span>
              {inspectedDio ? (
                <span className="font-mono text-emerald-700 font-semibold">24x7 Connected</span>
              ) : (
                <span className="font-mono text-slate-400 font-semibold">Not configured</span>
              )}
            </div>
          </div>

          <button
            onClick={() => selectDistrict(inspectedId)}
            className="w-full mt-1 py-1.5 bg-gov-primary hover:bg-gov-primary-dark text-white rounded text-xs font-bold transition-colors shadow-2xs"
          >
            तपशीलवार जिल्हा डॅशबोर्ड उघडा (View Full District Telemetry)
          </button>
        </div>
      </div>
    </div>
  );
};
